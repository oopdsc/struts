var msg = new Array();
msg[0] = "用户名用来登陆系统以及其他系统服务";
msg[1] = "<span class=\"icon\"></span>此手机号已注册,请更换其它手机号,或使用该<a href=\"signin.php?Email={#Email#}\" name=\"mobile_login _link\" class=\"more\">手机号登录</a>";
msg[2] = "<span class=\"icon\"></span>用户名过长,请选择其他用户名";
msg[3] = "<span class=\"icon\"></span>该邮箱已被注册,请更换其它邮箱,或使用该<a href=\"signin.php?Email={#Email#}\" name=\"email_login_link\" class=\"more\">邮箱登录</a>";
msg[4] = "<span class=\"icon\"></span>您的短信发送次数超过上限,请明天再试";
msg[5] = "<span class=\"icon\"></span>抱歉,您必须同意当当网的服务条款后,才能提交注册。";
msg[6] = "<span class=\"icon\"></span>用户名不能为空";
msg[7] = "密码为6-20个字符,可由英文、数字及符号组成";
msg[8] = "<span class=\"icon\"></span>登录密码不能为空";
msg[9] = "<span class=\"icon\"></span>密码长度6-20个字符,请重新输入";
msg[10] = "请再次输入密码";
msg[11] = "<span class=\"icon\"></span>两次输入的密码不一致,请重新输入";
msg[12] = "<span class=\"icon\"></span>密码不能为空";
msg[13] = "<span class=\"icon\"></span>密码不能包含“空格”,请重新输入";
msg[14] = "<span class=\"icon\"></span>图形验证码错误";
msg[15] = "<span class=\"icon\"></span>验证码错误";
msg[16] = "请输入图片中的字符,不区分大小写";
msg[17] = "还是没有收到短信？请检查您的手机明天再试";
msg[18] = "验证码已经发送到您的手机上";
msg[19] = "<span class=\"icon\"></span>网络繁忙,请稍后重新点击“注册”按钮重试。";
msg[20] = "<span class=\"icon\"></span>请输入图形验证码";
msg[21] = "重新获取验证码";
msg[22] = "<span class=\"icon\"></span>请输入验证码";
msg[23] =  "<span class=\"icon\"></span>密码为6-20位字符,只能由英文、数字及符号组成";

var checkEmail = false;
var checkpassword = false;
var checkRepassword = false;
var VerifyCode = false;
var checkpop_sms_vcode = false;
var checkpop_vcode = false;
var selectdomin=-1;
var showTimer=5000;
var show_t="";


function show_vcode(img_id) {
    $('#' + img_id).attr('src', 'p/tmp_proxy.php?t=' + new Date().getTime());
}

function show_error(err_code) {
    switch (err_code) {
        case 0:
            break;
        case 1:
            $('#txt_vcode').val('');
            $('#txt_vcode').attr('class', 'text wrong').css('border-color', '');
            $('#spn_vcode_ok').html('').attr('class', '');
            $('#spn_vcode_wrong').attr('class', 'cue');
            $('#spn_vcode_wrong').html(msg[14]);
            $('#spn_vcode_wrong').css({'display': ''});
            show_vcode('imgVcode');
            break;
        case 2:
            $('#txt_vcode').val('');
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[3].replace('{#Email#}', $('#txt_username').val()));
            $('#spn_username_wrong').css({'display': ''});
            break;
        case 3:
            $('#txt_vcode').val('');
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[2]);
            $('#spn_username_wrong').css({'display': ''});
            break;
        case 4:
            $('#txt_pop_vcode').val('');
            $('#txt_pop_vcode').attr('class', 'text wrong').css('border-color', '');
            $('#spn_pop_vcode_ok').hide();
            $('#p_pop_vcode_wrong').attr('class', 'cue');
            $('#p_pop_vcode_wrong').html(msg[14]);
            $('#p_pop_vcode_wrong').css({'display': ''});
            show_vcode('popImgVcode');
            break;
        case 5:
            $('#div_mask_cover').css({'display': 'none'});
            $('#div_identity_verification').css({'display': 'none'});
            $('#txt_pop_sms_vcode').val('');
            $('#txt_pop_vcode').val('');
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[2]);
            $('#spn_username_wrong').css({'display': ''});
            break;
        case 6:
            $('#txt_pop_sms_vcode').val('');
            $('#txt_pop_vcode').val('');
            $('#txt_pop_sms_vcode').attr('class', 'text wrong').css('border-color', '');
            $('#spn_pop_sms_vcode_ok').hide();
            $('#p_pop_sms_vcode_wrong').addClass('cue');
            $('#p_pop_sms_vcode_wrong').html(msg[15]);
            $('#p_pop_sms_vcode_wrong').css({'display': ''});
            show_vcode('popImgVcode');
            break;
        case 7:
            $('#div_mask_cover').css({'display': 'none'});
            $('#div_identity_verification').css({'display': 'none'});
            $('#txt_pop_sms_vcode').val('');
            $('#txt_pop_vcode').val('');
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[1].replace('{#Email#}', $('#txt_username').val()));
            $('#spn_username_wrong').css({'display': ''});
            break;
        case 8:
            $('#div_mask_cover').css({'display': 'none'});
            $('#div_identity_verification').css({'display': 'none'});
            $('#txt_pop_sms_vcode').val('');
            $('#txt_pop_vcode').val('');
            $('#txt_vcode').val('');
            $('#spn_err_msg').html(msg[19]);
            $('#spn_err_msg').css({'display': ''});
            break;
        case 9:
            $('#txt_vcode').val('');
            $('#txt_password').attr('class', 'text wrong').css('border-color', '');
            $('#spn_password_ok').hide();
            $('#spn_password_wrong').attr('class', 'cue');
            $('#spn_password_wrong').html(msg[9]);
            $('#spn_password_wrong').css({'display': ''});
            break;
        case 10:
            $('#txt_vcode').val('');
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[4]);
            $('#spn_username_wrong').css({'display': ''});
            break;
        case 11:
            $('#txt_vcode').val('');
            $('#spn_err_msg').html(msg[19]);
            $('#spn_err_msg').css({'display': ''});
            break;
        default:
            break;
    }
}

function check_focus(txtid, spn_ok, spn_wrong) {
    $(txtid).attr('class', 'text').css('border-color', '#FF8E42');
    $(spn_ok).hide();
    $(spn_wrong).attr('class', 'warn').css({'display': ''});
}

function check_capslock_open(e){
    var  e= window.event || e;
    var  n=e.keyCode || e.which;
    var  m=e.shiftKey||(n==16)||false;
    if (((n >= 65 && n <= 90) && !m) || ((n >= 97 && n <= 122 )&& m)) {
        $('#spn_password_wrong').css({'display': 'none'});
        $("#capslock_change").css("display","block");
    }
    else if(n >= 97 && n <= 122 && !m){
        $("#capslock_change").css("display","none");
    }
    else if(n==27){
        $("#capslock_change").css("display","none");
    }
}


function check_username_focus() {
    check_focus('#txt_username', '#spn_username_ok', '#spn_username_wrong');
    $('#spn_username_wrong').html(msg[0]);

}

function username_check() {    
    var username = $.trim($('#txt_username').val());
    $('#spn_username_ok').html('').hide();
    if($('#spn_username_wrong').attr("class")=="warn")
      $('#spn_username_wrong').html('').hide();
    $("#select_emaildomain").css("display","none");
    checkEmail = false;
    var usernameExist = false;
    if (username == '') {
        $('#spn_username_ok').hide();
        return false;
    }
    
    
    if (!/^\d+$/.test(username)) {          
        if (username.length > 40) {
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[2]);
            $('#spn_username_wrong').css({'display': ''});
            return false;
        }
        if (/[ ]/.test(username)) {
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[2]);
            $('#spn_username_wrong').css({'display': ''});
            return false;
        }
        
        $.ajax({
            type: 'POST',
            url: 'p/email_checker.php',
            data: 'email=' + username,
            async: false,
            success: function (flg) {
                if (flg == "true") {
                    $('#txt_username').attr('class', 'text wrong').css('border-color', '');
                    $('#spn_username_ok').hide();
                    $('#spn_username_wrong').attr('class', 'cue');
                    $('#spn_username_wrong').html(msg[3].replace('{#Email#}', username));
                    $('#spn_username_wrong').css({'display': ''});
                    usernameExist = true;
                    return;
                }
            }
        });
    } 
    if (usernameExist == true) {
        return false;
    }
    $('#txt_username').attr('class', 'text');
    $('#spn_username_wrong').hide();
    $('#spn_username_ok').html('');
    $('#spn_username_ok').attr('class', 'icon_yes');
    $('#spn_username_ok').css({'display': ''});
    checkEmail = true;
    return true;
}

function check_password_focus() {
    if($("#hid_txt_password").is(":visible")){
       hidden_visible_password();
       clearTimeout(show_t);
       $("#txt_password").focus();
    }else{
    check_focus('#txt_password', '#spn_password_ok', '#spn_password_wrong');
    $('#spn_password_wrong').html(msg[7]);
    $('#spnPwdStrongTips').hide();
    }
}


function password_check() {
    var password = $('#txt_password').val();
    $('#txt_password').attr('class', 'text');
    $('#spn_password_ok').hide();
    $('#spn_password_wrong').attr('class', 'warn');
    $('#spn_password_wrong').html(msg[7]);
    $('#spn_password_wrong').css({'display': ''});
    $("#capslock_change").css({'display': 'none'});
    checkpassword = false;
    if (password == '') {
        $('#spn_password_ok').hide();
        $('#spn_password_wrong').hide();
        $('#spnPwdStrongTips').hide();
        return false;
    }
    if (password.length < 6 || password.length > 20) {
        $('#txt_password').attr('class', 'text wrong').css('border-color', '');
        $('#spn_password_ok').hide();
        $('#spn_password_wrong').attr('class', 'cue');
        $('#spn_password_wrong').html(msg[9]);
        $('#spn_password_wrong').css({'display': ''});
        $('#spnPwdStrongTips').hide();
        return false;
    }
    if (!/^\S{1,20}$/.test(password)) {
        $('#txt_password').attr('class', 'text wrong').css('border-color', '');
        $('#spn_password_ok').hide();
        $('#spn_password_wrong').attr('class', 'cue');
        $('#spn_password_wrong').html(msg[13]);
        $('#spn_password_wrong').css({'display': ''});
        $('#spnPwdStrongTips').hide();
        return false;
    }
    
   for(var i=0;i<password.length;i++){
      if(password.charCodeAt(i)>127){
        $('#txt_password').attr('class', 'text wrong').css('border-color', '');
        $('#spn_password_ok').hide();
        $('#spn_password_wrong').attr('class', 'cue');
        $('#spn_password_wrong').html(msg[23]);
        $('#spn_password_wrong').css({'display': ''});
        $('#spnPwdStrongTips').hide();
        return false; 
        }
   }
     
    $('#txt_password').css("border-color","#7f9db9");
    $('#spn_password_wrong').hide();
    $('#spn_password_ok').hide();
    txtPassword_strong_check();
    checkpassword = true;
    return true;
}

function txtPassword_strong_check() {
    var password = $('#txt_password').val();
    var passwordTrim = $.trim(password);
    if (passwordTrim.length == 0) {
        $('#spnPwdStrongTips').css('display', 'none');
        $('#spn_password_wrong').html(msg[7]);
        $('#spn_password_wrong').css({'display': ''});
        return;
    }
    $('#spn_password_ok').hide();
    $('#spn_password_wrong').hide();
    $('#txt_password').attr('class', 'text');
    if (passwordTrim.length < 6) {
        $('#spnPwdStrong1').css('display', '');
        $('#spnPwdStrong2').hide();
        $('#spnPwdStrong3').hide();
        $('#spnPwdStrongTips').css('display', '');
        return;
    }
    
    if (passwordTrim.length > 20){    
        $('#txt_password').attr('class', 'text wrong').css('border-color', '');
        $('#spn_password_ok').hide();
        $('#spn_password_wrong').attr('class', 'cue');
        $('#spn_password_wrong').html(msg[9]);
        $('#spn_password_wrong').css({'display': ''});
        $("#capslock_change").css({'display': 'none'});
        $('#spnPwdStrongTips').hide();
        return false;
    }
    var chenum = checkStrong();
    if (chenum == 0) {
        return;
    } else if (chenum == 1) {
        $('#spnPwdStrong1').css('display', '');
        $('#spnPwdStrong2').hide();
        $('#spnPwdStrong3').hide();
    } else if (chenum == 2) {
        $('#spnPwdStrong1').hide();
        $('#spnPwdStrong2').css('display', '');
        $('#spnPwdStrong3').hide();
    } else if (chenum >= 3) {
        $('#spnPwdStrong1').hide();
        $('#spnPwdStrong2').hide();
        $('#spnPwdStrong3').css('display', '');
    }
    $('#spnPwdStrongTips').css('display', '');
    return;
}

function check_repassword_focus() {
    if($("#hid_txt_repassword").is(":visible")){
       hidden_visible_password();
       clearTimeout(show_t);
       $("#txt_repassword").focus();
       check_focus('#txt_repassword', '#spn_repassword_ok', '#spn_repassword_wrong');
       $('#txt_repassword').css("color","black");
       $('#spn_repassword_wrong').html(msg[10]);
    }else{
    check_focus('#txt_repassword', '#spn_repassword_ok', '#spn_repassword_wrong');
    $('#txt_repassword').css("color","black");
    $('#spn_repassword_wrong').html(msg[10]);
    }
}

function repassword_check() {
    if($('#spn_repassword_wrong').attr('class')=="cue")
     return ;
    var rep_password = $('#txt_repassword').val();
    $('#txt_repassword').attr('class', 'text');
    $('#spn_repassword_ok').hide();
    $('#spn_repassword_wrong').attr('class', 'warn');
    $('#spn_repassword_wrong').html(msg[7]);
    $('#spn_repassword_wrong').css({'display': ''});
    checkRepassword = false;
    if (rep_password == '') {
        $('#spn_repassword_ok').hide();
        $('#spn_repassword_wrong').hide();
        return false;
    }
    if (rep_password != $('#txt_password').val()) {
        var  p_password=$('#txt_password').val();
        var  k="false";l="false";
        var  j=1;
        for(var i=0;i<p_password.length;i++){
            if(p_password.charAt(i)!=rep_password.charAt(i) && i<p_password.length && l=="false"){
               j+=i;
               k="true";
               l="true";
            }          
        }
        if(k=="false")
        j=p_password.length+1;
        var errmind="第"+j+"位输入错误";
        var errhtml="<span class=\"icon\"></span><span id=\"pwrong_mind\">"+errmind+"</span><a id=\"a_show_pass\"  href=\"javascript:show_visible_password();\" class=\"show_pass\"   style=\"display:;\";>显示密码</a>";   
        $('#txt_repassword').attr('class', 'text wrong').css('border-color', '');
        $('#spn_repassword_ok').hide();
        $('#txt_repassword').css("color","red");
        $('#spn_repassword_wrong').attr('class', 'cue');
        $('#spn_repassword_wrong').html(errhtml);
        $('#spn_repassword_wrong').css({'display': ''});
        return false;
    }
    if (password_check()) {
        $('#spn_repassword_ok').css({'display': ''});
    } else {
        $('#spn_repassword_ok').hide();
    }
    $('#txt_repassword').css("border-color","#7f9db9");
    $('#spn_repassword_wrong').hide();
    $('#spn_repassword_ok').html('');
    $('#spn_repassword_ok').attr('class', 'icon_yes');
    checkRepassword = true;
    return true;
}

function repassword_session_check(){
     var password= $('#txt_password').val();
     var rep_password = $('#txt_repassword').val();
     var nLen=rep_password.length;
     if(nLen>0 &&  $('#spn_repassword_wrong').attr("class")!='cue'){
       for(var i=0 ;i<nLen;i++){
          if(password.charAt(i)!=rep_password.charAt(i)){ 
            var errBit=i+1;
            var errmind="第"+errBit+"位输入错误";
            var errhtml="<span class=\"icon\"></span><span id=\"pwrong_mind\">"+errmind+"</span><a id=\"a_show_pass\"  href=\"javascript:show_visible_password();\" class=\"show_pass\"   style=\"display:;\";>显示密码</a>";   
            $('#txt_repassword').attr('class', 'text wrong').css('border-color', '');
            $('#spn_repassword_ok').hide();
            $('#txt_repassword').css("color","red");
            $('#spn_repassword_wrong').attr('class', 'cue');
            $('#spn_repassword_wrong').html(errhtml);
            $('#spn_repassword_wrong').css({'display': ''});
            return false;
          }
       }
     }else if (nLen==0){
            check_focus('#txt_repassword', '#spn_repassword_ok', '#spn_repassword_wrong');
            $('#txt_repassword').css("color","black");
            $('#spn_repassword_wrong').html(msg[10]);
     }
     else 
     {    
           for(var i=0 ;i<nLen;i++){
                if(password.charAt(i)!=rep_password.charAt(i))
                 return  false;
           }

           $('#txt_repassword').css("color","black");
           $('#spn_repassword_wrong').html(msg[10]);
           $('#txt_repassword').attr('class', 'text').css('border-color', '#FF8E42');
           $('#spn_repassword_ok').hide();
           $('#spn_repassword_wrong').attr('class', 'warn').css({'display': ''});
    
     }
}


function  show_visible_password(){
     var v_password= $("#txt_password").val();
     var v_repassword=$("#txt_repassword").val();  
     $("#txt_password").css("display","none");
     $("#a_show_pass").css("display","none");
     $("#hid_txt_password").css("display","");
     $("#txt_repassword").css("display","none");
     $("#hid_txt_repassword").css("display","");
     $('#hid_txt_repassword').attr('class', 'text wrong').css('border-color', '');
     $("#hid_txt_password").val(v_password);
     $("#hid_txt_repassword").val(v_repassword);
      show_t=setTimeout(function() {
          hidden_visible_password();
     }, showTimer);
}

function  hidden_visible_password(){
     $("#hid_txt_password").css("display","none");
     $("#txt_password").css("display","");
     $("#hid_txt_repassword").css("display","none");
     $("#txt_repassword").css("display","");
     $("#a_show_pass").css("display","");
}


function checkStrong() {
    var sPW = $('#txt_password').val();
    if (sPW.length < 1)
        return 0;
    Modes = 0;
    for (i = 0; i < sPW.length; i++) {
        Modes |= Evaluate(sPW.charCodeAt(i));
    }
    var num = bitTotal(Modes);
    return num;
}
function Evaluate(character) {
    if (character >= 48 && character <= 57)
        return 1;
    if (character >= 65 && character <= 90)
        return 2;
    if (character >= 97 && character <= 122)
        return 4;
    else
        return 8;
}

function bitTotal(num) {
    modes = 0;
    for (i = 0; i < 4; i++) {
        if (num & 1) modes++;
        num >>>= 1;
    }
    return modes;
}

function CheckdoSubmit(e) {
    var ev = window.event || e;
    if (ev.keyCode == 13) {
        check_register();
    }
}

function reg_submit(buttonname) {
    if (buttonname == "regbutton") {
        return true;
    } else {
        return false;
    }
}

function check_register() {
    var usernameTrim = $('#txt_username').val();
    var passwordTrim = $('#txt_password').val();
    var repasswordTrim = $('#txt_repassword').val();

    if ($.trim(usernameTrim) == "" || $.trim(passwordTrim) == "" || $.trim(repasswordTrim) == "") {
        if ($.trim(usernameTrim) == "") {
            $('#txt_username').attr('class', 'text wrong').css('border-color', '');
            $('#spn_username_ok').hide();
            $('#spn_username_wrong').attr('class', 'cue');
            $('#spn_username_wrong').html(msg[6]);
            $('#spn_username_wrong').css({'display': ''});
        }
        if ($.trim(passwordTrim) == "") {
            $('#txt_password').attr('class', 'text wrong').css('border-color', '');
            $('#spn_password_ok').hide();
            $('#spn_password_wrong').attr('class', 'cue');
            $('#spn_password_wrong').html(msg[8]);
            $('#spn_password_wrong').css({'display': ''});
        }
        if ($.trim(repasswordTrim) == "") {
            $('#txt_repassword').attr('class', 'text wrong').css('border-color', '');
            $('#spn_repassword_ok').hide();
            $('#spn_repassword_wrong').attr('class', 'cue');
            $('#spn_repassword_wrong').html(msg[12]);
            $('#spn_repassword_wrong').css({'display': ''});
        }

        return false;
    }
    if (username_check() && password_check() && repassword_check()) {
        $('#hdn_username').val($.trim(usernameTrim));
        $('#hdn_password').val($.trim(passwordTrim));
        if(/^\w+((\.\w+)|(-\w+))*\@[a-zA-Z0-9]+((\.|-)[a-zA-Z0-9]+)*\.[a-zA-Z0-9]+$/.test($.trim(usernameTrim))) {
            // email注册
            $("#register_form").attr("onsubmit","return true;");      
            $('#btn_confirm').click();
        }
        return true;
    }
    return false;
}


function CheckdoPopSubmit(e) {
    var ev = window.event || e;
    if (ev.keyCode == 13) {
        
    }
}

function pop_reg_submit(buttonname) {
    if (buttonname == "popregbutton") {
        return true;
    } else {
        return false;
    }
}
