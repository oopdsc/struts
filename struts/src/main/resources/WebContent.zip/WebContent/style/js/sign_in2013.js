try{
    document.domain='dangdang.com';
}
catch(err){}
var login_checkscript_domin="login.dangdang.com";
var login_vcode_check_url="/p/vcode_checkscript.php?vcode={0}";
var login_vcode_url="/p/tmp_proxy.php";
var login_username_check_url="/p/emailandmobile_check.php?usermobile={0}";
var login_returnurl="";
var login_su_check_do="/p/authen_humans_check.php?su_key={0}";
var login_su_key="";
function txtPassword_keyDown(e,obj)
{
    var ev = window.event || e;
    if(ev.keyCode == 13){
        sign_check_and_submit(true);
        return false;
    }
}

function do_submit(){

    if(!navigator.cookieEnabled)
    {
        alert("请您打开浏览器的Cookie功能！");
        return false;
    }

    if(jQuery.trim(jQuery("#txtUsername").val()) == '')
    {
        jQuery("#user_mindstyle").addClass("error_words");
        jQuery("#liDivErrorMessage").show();
        jQuery("#liDivErrorMessage").html("请输入您的邮箱、昵称或手机号码");
        jQuery("#username_div").addClass('error');
        jQuery("#txtUsername").attr("errordata","1");
        jQuery("#userReplacer").css("display","none");
        jQuery("#txtUsername").focus();   
        return false;
    }
    jQuery("#liDivErrorMessage").hide();
    if(jQuery.trim(jQuery('#txtPassword').val())=='')
    {
        jQuery("#txtPassword").attr("errordata","1");
        jQuery("#txtPassword").focus();
        echo_error_message(7);
        return false;
    }
    jQuery("#login_password_error").hide();
    var vcode = jQuery.trim(jQuery('#txtVerifyCode').val());
    if(vcode=='' || !/\w{4}/.test(vcode))
    {
        jQuery('#txtVerifyCode').attr("errordata","1");
        jQuery('#txtVerifyCode').focus();
        echo_error_message(6);
        return false;
    }
    jQuery('#login_vcode_error').hide();
    return true;
}


function check_submit(){

    return sign_check_and_submit(false);
}

function sign_check_and_submit(enterkey)
{
    if(!navigator.cookieEnabled)
    {
        alert("请您打开浏览器的Cookie功能！");
        return false;
    }

    if(jQuery.trim(jQuery("#txtUsername").val()) == '')
    {
        jQuery("#user_mindstyle").addClass("error_words");
        jQuery("#liDivErrorMessage").show();
        jQuery("#liDivErrorMessage").html("请输入您的邮箱、昵称或手机号码");
        jQuery("#username_div").addClass('error');
        jQuery("#txtUsername").attr("errordata","1");
        jQuery("#userReplacer").css("display","none");
        jQuery("#txtUsername").focus();
        
        return;
    }
    if(jQuery("#sile_login").is(":visible")){
      if(jQuery("#txtUsername").val()!=jQuery("#save_username").attr('info')){
        jQuery("#txtUsername").val(jQuery("#save_username").attr('info'));
      }
    }
    jQuery("#liDivErrorMessage").hide();
    if(jQuery.trim(jQuery('#txtPassword').val())=='')
    {
        jQuery("#txtPassword").attr("errordata","1");
        if(!enterkey)
            jQuery("#txtPassword").focus();
        jQuery("#password_div").addClass('error');
        echo_error_message(7);
        return false;
    }
    jQuery("#login_password_error").hide();
    var  user_loginname=jQuery("#txtUsername").val().replace('#', '%C').replace('+', '%C').replace('&','%C');
    jQuery.getJSON(login_username_check_url.replace("{0}",user_loginname)+"&t="+new Date().getTime()+"&jsoncallback=?",function(data){
         var getdata=jQuery.trim(data.returnval);
        if(getdata=="0"){//检测正常可以继续检查其他项
            jQuery("#login_type").val(data.type);
            check_vcode_submit();
            return false;
        }
        if(getdata=="1"){//用户名不存在
            jQuery("#txtUsername").attr("errordata","2");
            jQuery("#txtUsername").focus();
            var userloginname=jQuery("#txtUsername").val();
            jQuery("#txtUsername").textposition(userloginname.length);
            jQuery('#txtPassword').val("");
            echo_error_message(5);
            return false;
        }
        if(getdata=="2"){//用户输入的手机号码存在与昵称冲突的情况，显示选择用户类型
            if(jQuery("#selusertypemail").attr("checked")||jQuery("#selusertypemobile").attr("checked")||jQuery("#txtUsername").attr('utype')!=''){
                if(jQuery("#txtUsername").attr('utype')!='') jQuery("#login_type").val(jQuery("#txtUsername").attr('utype'));
                check_vcode_submit();
                return false;
            }
            showusertype();
            return false;
        }
    });
    return false;
}


function check_vcode_submit(){

    if(jQuery("#inputcode").is(":visible")){
        txtVerifyCode_check();
    }else{
        jQuery("#Form1").attr("onsubmit","return true;")
        jQuery('#btnSign').click();
    }
}
function txtVerifyCode_check(arg){

    var vcode = jQuery.trim(jQuery('#txtVerifyCode').val());
    if(vcode==''||!/(\W{2}|\W{4}|\w{2}|\w{4})/.test(vcode))
    {
        jQuery('#txtVerifyCode').attr("errordata","1");
        jQuery('#txtVerifyCode').focus();
        if(vcode=='')
            echo_error_message(11);
        else
            echo_error_message(6);
        return false;
    }
    jQuery('#login_vcode_error').hide();
    var url=login_vcode_check_url.replace("{0}",escape(vcode))+"&t="+new Date().getTime();
    jQuery.getScript(url);;
}

function show_vcode(img_id){
  jQuery("#imgVcode").attr("src", login_vcode_url+"?t="+new Date().getTime());
  document.getElementById("txtVerifyCode").value="";
}

function showusertype(){
    jQuery("#user_mindstyle").addClass("winerror02");
    jQuery("#selecttype").css('display','block');
    jQuery("#liDivErrorMessage").hide();
    jQuery("#txtPassword").attr("readonly","readonly");
       
}

function hideusertype(num){
    jQuery("#login_type").val(num);
    jQuery("#user_mindstyle").removeClass("winerror02");
    jQuery("#selecttype").css('display','none');
    jQuery("#txtPassword").removeAttr("readonly");  
    var passwordval=jQuery("#txtPassword").val();
    jQuery("#txtPassword").textposition(passwordval.length);
    if(num=="0"){
        jQuery("#selectusertype").removeClass("replacetype01").addClass("replacetype02");
    }else{
        jQuery("#selectusertype").removeClass("replacetype02").addClass("replacetype01");
    }
    jQuery("#selectusertype").show();
}
function focus_pass(){
    if(jQuery("#txtPassword").attr("errordata")=="0"){
        jQuery('#password_div').removeClass('error').addClass("focus");
        jQuery('#pass_mindstyle').removeClass().addClass("tips");
        jQuery('#login_password_error').css("display","block");
        jQuery("#casplockopen").hide();
        jQuery('#login_password_error').html("请填写长度为6-20个字符的密码");
        jQuery("#pwdReplacer").css("display","none");
    }
}


function focus_username(){
    if(jQuery("#txtUsername").attr("errordata")=="0"){
        jQuery("#username_div").removeClass('error').addClass("focus");  
        jQuery('#user_mindstyle').removeClass('error_words').addClass("tips");
        jQuery('#liDivErrorMessage').css("display","block");
        jQuery('#liDivErrorMessage').html("请输入邮箱地址/昵称/手机号码");
        jQuery("#userReplacer").css("display","none");
    }
}


function focus_user_change(){
    jQuery("#txtUsername").attr("errordata","0");
}


function check_user_change(){
     if(jQuery.trim(jQuery("#txtUsername").val())=="")
         return  false;
     if(jQuery.trim(jQuery("#txtUsername").val())==login_su_key)
         return  false;
     login_su_key=jQuery.trim(jQuery("#txtUsername").val());
     var su_id=jQuery.trim(jQuery("#txtUsername").val().replace('#', '%C').replace('+', '%C').replace('&','%C'));
     jQuery.getJSON(login_su_check_do.replace("{0}",su_id)+"&su_do="+new Date().getTime()+"&domain=basic_login"+"&jsoncallback=?",function(data){
       var  su_backinfo=data;
        if(su_backinfo.check_person=="false"){
            jQuery("#auth_human_id").val(su_backinfo.person_repid);      
            if(!jQuery("#inputcode").is(":visible")){
               jQuery("#inputcode").css("display","block");
               jQuery("#vcode_mindstyle").show();
               jQuery("#share_login").css('margin-top','0px');
               show_vcode("imgVcode");
            }
        }
        else if(su_backinfo.check_person=="true"){
            jQuery("#auth_human_id").val(su_backinfo.person_repid);
        }
    });
    return  true;
}

function check_password_change(){
     if(jQuery("#txtPassword").val()!=""){
        jQuery("#pwdReplacer").css("display","none"); 
    }
}

function focus_pass_change(){
    jQuery("#txtPassword").attr("errordata","0");
}

function blur_username(){
    jQuery('#username_div').removeClass().addClass("username");
    if(jQuery("#txtUsername").attr("errordata")!="2"){
      jQuery('#liDivErrorMessage').hide();
      if(jQuery.trim(jQuery("#txtUsername").val()) ==""){   
        jQuery("#userReplacer").css("display","block");;
      }
    }
    
}
function blur_password(){
    jQuery('#login_password_error').hide();
    jQuery("#password_div").removeClass().addClass('password');
    if(jQuery("#txtPassword").val() ==""){
        jQuery("#pwdReplacer").css("display","block"); 
    }
}
function focus_vcode(){
    if(jQuery("#txtVerifyCode").attr("errordata")=="0"){
        jQuery('#vcode_model').removeClass("normal").addClass("focus");
        jQuery('#vcode_mindstyle').removeClass().addClass("tips_code");
        jQuery('#login_vcode_error').css("display","block");
        jQuery('#login_vcode_error').html("请填写图片中的字符，不区分大小写");
        jQuery("#codeReplacer").css("display","none");
    }
    if(jQuery("#casplockopen").is(":visible")){ 
       jQuery('#password_div').removeClass("error").addClass("focus");
       jQuery('#login_password_error').css("display","none");
       jQuery("#pass_mindstyle").removeClass("winerror");
       jQuery("#casplockopen").hide();
    }
}

function blur_vcode(){
    jQuery('#login_vcode_error').css('display','none');
    jQuery('#txtVerifyCode').attr("errordata","0");
    jQuery("#vcode_model").removeClass().addClass("code");
    if(jQuery.trim(jQuery("#txtVerifyCode").val())==""){
       jQuery("#codeReplacer").css("display","block");;  
    }
}

function sign_submit(){
    jQuery("#Form1").attr("onsubmit","return true;")
    jQuery('#btnSign').click();
}

var  autologin={
     ischecked:function(){
      if(jQuery('#autologin').attr('checked')){
					jQuery('.auto_login').find('span').css("display","none");
					jQuery('.auto_login').find('.safe').css("display","inline-block");
           jQuery('#ispersist').val('on');
				}
        else{
          	jQuery('.auto_login').find('span').css("display","");
					jQuery('.auto_login').find('.safe').css("display","none");
           jQuery('#ispersist').val('off');
        }
    }
}

function echo_error_message(code)
{
    switch(code)
    {
        case 1:
            jQuery("#submit_signin_div").removeClass("login_btn02");
            break
        case 2:
            jQuery('#txtPassword').focus();
            jQuery("#password_div").removeClass('focus').addClass('error');
            jQuery('#pass_mindstyle').addClass("error_words");
            jQuery('#login_password_error').css("display","block");
            jQuery('#login_password_error').html("用户名或密码输入错误，请重新填写");
            jQuery("#pwdReplacer").css("display","none");
            jQuery('#txtPassword').attr("errordata","1");
            jQuery('#txtPassword').val('');
            jQuery('#txtPassword').focus();
            jQuery("#selusertypemail").attr("checked",false);
            jQuery("#selusertypemobile").attr("checked",false);
            if(jQuery("#inputcode").is(":visible"))show_vcode('imgVcode');         
            break;
        case 3:
            jQuery("#inputcode").show();
            jQuery("#vcode_mindstyle").show();
            jQuery("#share_login").css('margin-top','0px');
            jQuery("#vcode_model").addClass('error');
            jQuery("#vcode_mindstyle").addClass("error_words");
            jQuery('#login_vcode_error').css("display","block");
            jQuery("#codeReplacer").css("display","none");
            jQuery('#login_vcode_error').html("验证码输入错误，请重新填写");
            jQuery('#txtVerifyCode').attr("errordata","1");
            jQuery('#txtVerifyCode').val('');
            jQuery('#txtVerifyCode').focus();           
            jQuery("#selusertypemail").attr("checked",false);
            jQuery("#selusertypemobile").attr("checked",false);
            show_vcode('imgVcode');
            break;
        case 4:
            jQuery("#vcode_model").removeClass('focus').addClass('error');
            jQuery("#vcode_mindstyle").addClass("error_words");
            jQuery('#login_vcode_error').css("display","block");
            jQuery("#codeReplacer").css("display","none");
            jQuery('#login_vcode_error').html("验证码输入错误，请重新填写");
            jQuery('#txtVerifyCode').attr("errordata","1");
            jQuery('#txtVerifyCode').val('');
            jQuery('#txtVerifyCode').focus();
            show_vcode('imgVcode');
            break;
        case 5:
            jQuery("#liDivErrorMessage").show();
            jQuery("#user_mindstyle").addClass("error_words");
            jQuery("#username_div").addClass('error');
            if(/^[.\-_a-zA-Z0-9]+@[\-_a-zA-Z0-9]+\.[a-zA-Z0-9]/.test(jQuery('#txtUsername').val()))
                jQuery("#liDivErrorMessage").html("该用户名不存在，<a href=\"register.php?email="+jQuery('#txtUsername').val()+"&returnurl="+login_returnurl+"\">免费注册</a>");
            else
                jQuery("#liDivErrorMessage").html("该用户名不存在，<a href=\"register.php?returnurl="+login_returnurl+"\">免费注册</a>");
            break;
        case 6:
            jQuery("#vcode_model").addClass('error');
            jQuery("#vcode_mindstyle").addClass("error_words");
            jQuery('#login_vcode_error').css("display","block");
            jQuery('#login_vcode_error').html("验证码输入错误，请重新填写");
            jQuery("#codeReplacer").css("display","none");
            break;
        case 7:
            jQuery('#pass_mindstyle').addClass("error_words");
            jQuery('#login_password_error').css("display","block");
            jQuery('#login_password_error').html("请输入您的登录密码");
            jQuery("#pwdReplacer").css("display","none");
            break;
        case 8:
            jQuery("#liDivErrorMessage").removeClass("error").addClass("hint");
            jQuery("#liDivErrorMessage").html("请输入邮箱/昵称/手机号码");
            break;
        case 9:
            jQuery('#vcodeerrormassage').removeClass("error").addClass("hint");
            jQuery('#vcodeerrormassage').html("验证码输入错误，请重新填写");
            jQuery("#chk_vcodeok").hide();
        case 10:
            jQuery('#vcodeerrormassage').removeClass("error").addClass("hint");
            jQuery('#vcodeerrormassage').html("注册失败");
            jQuery("#chk_vcodeok").hide();
        case 11:
            jQuery("#vcode_model").addClass('error');
            jQuery("#vcode_mindstyle").addClass("error_words");
            jQuery('#login_vcode_error').css("display","block");
            jQuery('#login_vcode_error').html("请输入验证码"); 
            jQuery("#codeReplacer").css("display","none");
            break;
        case 12:
            jQuery("#login_password_error").removeClass("hint").addClass("error");
            jQuery('#login_password_error').css("display","block");
            jQuery('#login_password_error').html("用户尚未验证，请验证后登录！");
            jQuery('#txtVerifyCode').val('');
            jQuery("#selusertypemail").attr("checked",false);
            jQuery("#selusertypemobile").attr("checked",false);
            if(jQuery("#winlogin_vcode").is(":visible"))show_vcode('imgVcode');
            jQuery("#submit_signin_div").removeClass("login_btn02");
            break;
            case 14:
            jQuery("#inputcode").show();
            jQuery("#vcode_mindstyle").show();  
            jQuery("#share_login").css('margin-top','0px');
            jQuery("#vcode_model").addClass('error');
            jQuery("#vcode_mindstyle").addClass("error_words");
            jQuery('#login_vcode_error').css("display","block");
            jQuery("#codeReplacer").css("display","none");
            jQuery('#login_vcode_error').html("为了你的账户安全，请输入验证码");
            jQuery('#txtVerifyCode').attr("errordata","1");
            jQuery('#txtVerifyCode').val('');
            jQuery('#txtVerifyCode').focus();           
            jQuery("#selusertypemail").attr("checked",false);
            jQuery("#selusertypemobile").attr("checked",false);
            show_vcode('imgVcode');
            break;
        default:
            break;
    }
}


jQuery.fn.extend({
    textposition:function( value ){
        var elem = this[0];
        if (elem&&(elem.tagName=="TEXTAREA"||elem.type.toLowerCase()=="text")) {
            if(jQuery.browser.msie){
                var rng;
                if(elem.tagName == "TEXTAREA"){
                    rng = event.srcElement.createTextRange();
                    rng.moveToPoint(event.x,event.y);
                }else{
                    rng = document.selection.createRange();
                }
                if( value === undefined ){
                    var txt=this.val();
                    rng.moveStart("character",-txt.length);
                    return  rng.text.length;
                }else if(typeof value === "number" ){
                    var index=this.textposition();
                    index>value?( rng.moveEnd("character",value-index)):(rng.moveStart("character",value-index))
                    rng.select();
                }
            }else{
                if( value === undefined ){
                    return elem.selectionStart;
                }else if(typeof value === "number" ){
                    elem.selectionEnd = value;
                    elem.selectionStart = value;
                }
            }
        }else{
            if( value === undefined )
                return undefined;
        }
    }
})
function submit_signin_button(){
    document.form1.submit();
}

/**
 * js清除cookie信息
 */
function clearcookie(name)
{
    var expdate = new Date(); 
    expdate.setTime(expdate.getTime() - (86400 * 1000 * 1)); 
    document.cookie= name+'="";Domain=dangdang.com;expires="' + expdate.toGMTString();
}
/**
 * 判断是否是火狐浏览器，定时检查密码是否为空，执行相关操作
 */
var  fire={
      t:200,
      s:'',
     isfirefox:function(){
         fire.fire_run();
     },
     fire_run:function(){
         setInterval(fire.filled_pass_check,100);
     },
     filled_pass_check:function(){
        if(jQuery("#txtUsername").val() !="")
        jQuery("#userReplacer").css("display","none");
        if(jQuery("#txtPassword").val() !="")
        jQuery("#pwdReplacer").css("display","none"); 
     }
}

function openWind(){
    var sinaloginurl="https://login.dangdang.com/login_third_sina/login_weibo.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-420)/2;
    var left=(document.body.clientWidth-520)/2;
    window.open(sinaloginurl,'sina_login', 'height=448, width=620, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function toQzoneLogin()
{
    childWindow = window.open("https://login.dangdang.com/login_third_qqoauth/login_qq_oauth.aspx?returnurl="+login_returnurl,"TencentLogin","width=600,height=420,menubar=no,scrollbars=yes, resizable=yes,status=yes,titlebar=no,toolbar=no,location=yes");
}

function openWind_renren(){
    var sinaloginurl="https://login.dangdang.com/login_third_renren/login_renren.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-420)/2;
    var left=(document.body.clientWidth-520)/2;
    window.open(sinaloginurl,'renren_login', 'height=448, width=620, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_netease(){
    var sinaloginurl="https://login.dangdang.com/login_third_netease/login_netease.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-420)/2;
    var left=(document.body.clientWidth-520)/2;
    window.open(sinaloginurl,'netease_login', 'height=448, width=620, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_msn(){
    var sinaloginurl="https://login.dangdang.com/login_third_msn/login_msn.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-420)/2;
    var left=(document.body.clientWidth-520)/2;
    window.open(sinaloginurl,'msn_login', 'height=448, width=620, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_shengda(){
    var sinaloginurl="https://login.dangdang.com/login_third_shengda/login_shengda.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-420)/2;
    var left=(document.body.clientWidth-520)/2;
    window.open(sinaloginurl,'shengda_login', 'height=448, width=620, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_baidu(){
    var sinaloginurl="https://login.dangdang.com/login_third_baidu/login_baidu.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-420)/2;
    var left=(document.body.clientWidth-520)/2;
    window.open(sinaloginurl,'baidu_login', 'height=448, width=620, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_mail139(){
    var sinaloginurl="https://login.dangdang.com/login_third_mail139/login_mail139.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-520)/2;
    var left=(document.body.clientWidth-880)/2;
    window.open(sinaloginurl,'mail139_login', 'height=448, width=980, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_fetion(){
    var sinaloginurl="https://login.dangdang.com/login_third_fetion/login_fetion.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-420)/2;
    var left=(document.body.clientWidth-520)/2;
    window.open(sinaloginurl,'fetion_login', 'height=448, width=620, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_jsmobile(){
    var sinaloginurl="https://login.dangdang.com/login_third_jsmobile/login_jsmobile.aspx?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-580)/2;
    var left=(document.body.clientWidth-680)/2;
    window.open(sinaloginurl,'js_mobile', 'height=640, width=900, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_douban(){
    var sinaloginurl="https://login.dangdang.com/login_third_douban/login_douban.php?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-580)/2;
    var left=(document.body.clientWidth-680)/2;
    window.open(sinaloginurl,'douban', 'height=448, width=442, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_qh360(){
    var sinaloginurl="https://login.dangdang.com/login_third_360/login_360.php?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-580)/2;
    var left=(document.body.clientWidth-680)/2;
    window.open(sinaloginurl,'qh_360', 'height=640, width=900, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}

function openWind_souhu(){
    var shloginurl="https://login.dangdang.com/login_third_sohu/login_sohu.php?returnurl="+login_returnurl;
    var top=(document.body.clientHeight-580)/2;
    var left=(document.body.clientWidth-680)/2;
    window.open(shloginurl,'souhu', 'height=640, width=900, toolbar =no, menubar=no, scrollbars=yes, resizable=no,top='+top+',left='+left+', location=yes, status=no');
}